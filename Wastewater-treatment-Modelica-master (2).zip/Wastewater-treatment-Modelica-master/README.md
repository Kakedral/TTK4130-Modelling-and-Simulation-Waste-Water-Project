# Wastewater-treatment-Modelica

Repo for storing the files/models used in the Wastewater ModSim project. 

